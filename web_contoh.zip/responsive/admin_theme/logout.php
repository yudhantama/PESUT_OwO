<?php
//session_start();
session_destroy();
//print("Anda telah sukses <b>LOGOUT</b>");
header('location:login.php');
?>
