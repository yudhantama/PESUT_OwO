<html>
<head>
<title>Adminsitrator Blog AMCC</title>
<link href="asset/css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="login">
    <div id="login_a"></div>
    <form method="post" action="cek_login.php">
    <div id="login_b">
        <div id="login_ba">Selamat Datang Silahkan Login</div>
        <div id="login_bb">
            <table width="100%">
                <tr>
                    <td>Username</td>
                </tr>
                <tr>
                    <td><input type="text" name="username" class="form"></td>
                </tr>
                <tr>
                    <td>Kata Sandi</td>
                </tr>
                <tr>
                    <td><input type="password" name="password" class="form"></td>
                </tr>
                <tr>
                    <td><input type="submit" value="Login" class="submit"></td>
                </tr>
            </table>
        </div>
    </div>
    </form>
</div>
</body>
</html>
