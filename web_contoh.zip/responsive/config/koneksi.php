<?php

mysql_connect("localhost","root","") or exit("Gagal koneksi database!");
mysql_select_db("company06") or exit("Gagal mengaktifkan database!");

?>